import java.io.*;
import java.util.ArrayList;

public class Conf{
    public int port = 8080;
    public String path;
    public static ArrayList<Object> lireEtConvertir(String filePath) {
        ArrayList<Object> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))){
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split("=");
                if(values[0] == "port"){
                    data.add(Integer.parseInt(values[0]));
                    
                }else{
                    data.add(values[1]);
                }
            }
        }catch (IOException e){
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
        return data;
    }
    public Conf(){
        //ArrayList<Object> cf = lireEtConvertir("Serveur.conf");
        //this.port = (int)cf.get(0);
        //this.path = (String)cf.get(1);
       // ArrayList<Object> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Serveur.conf"))){
            String line;
   
            while ((line = br.readLine()) != null) {
                String[] values = line.split("=");
                if(values[0].equals("port")){
                    this.port = Integer.parseInt(values[1]);
                }else if (values[0].equals("path")){
                    this.path=values[1];
                }
            }
        }catch (IOException e){
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
    }
}