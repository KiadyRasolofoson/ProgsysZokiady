

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerHTTP {
    public static void main(String[] args) {
        Conf cf = new Conf();
        //int port = cf.port;
        int port = cf.port;
        String cheminFichierHTML = cf.path ;
        try(
            ServerSocket serverSocket = new ServerSocket(port);
            
        )
         {
            System.out.println("Serveur HTTP démaré sur le port :"+port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nouvelle connéction client : "+clientSocket.getInetAddress());
                

                BufferedReader brCLient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String requete = brCLient.readLine();
                if (requete == null) {
                    System.out.println("Requête null reçue. Connexion fermée par le client.");
                    continue; // Continuer avec la prochaine connexion
                }
                System.out.println("REQUETE : "+requete);
                if (requete.contains("GET /favicon.ico")) {
                    String response = "HTTP/1.1 204 No Content\r\n\r\n"; // Pas de contenu pour favicon
                    OutputStream output = clientSocket.getOutputStream();
                    output.write(response.getBytes());
                    output.flush();
                    clientSocket.close();
                    continue;
                }
                
                cheminFichierHTML = extraireChemin(requete , cheminFichierHTML);
                String contenuPage = LireFichierHTML(cheminFichierHTML);
                
                    String response = null;
                    if (cheminFichierHTML.endsWith(".php")) {
                        contenuPage = executePHP(cheminFichierHTML,requete);
                        response = "HTTP/1.1 200 OK\r\n" +
                  "Content-Type: text/html; charset=UTF-8\r\n" +
                  "\r\n" + // Ligne vide entre les en-têtes et le corps
                  contenuPage;

                    }
                    if (cheminFichierHTML.endsWith(".html")) {
                        contenuPage = LireFichierHTML(cheminFichierHTML);
                        response = """
                            HTTP/1.1 200 OK
                            Content-Type: text/html; charset=UTF-8
                            """+contenuPage;
                    }
                    System.err.println("RESPONSE : " + response);
                    OutputStream output = clientSocket.getOutputStream();
                output.write(response.getBytes());
                output.flush();
                if (Thread.currentThread().isInterrupted()) {
                    break;
                }
                

            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur :"+e.getMessage());
        }
        
    }
    
    public static String LireFichierHTML(String chemin) throws IOException {{
        StringBuilder html = new StringBuilder();
        try(BufferedReader reader = new BufferedReader(new FileReader(chemin))){
            String ligne ;
            while ((ligne=reader.readLine())!=null) {
                html.append(ligne).append("\n");
            }
        }
        return html.toString() ;
    }
}public static String executePHP(String chemin, String requete) {
    StringBuilder sb = new StringBuilder();
    try {
        String params = null;
        
        // Extraire les paramètres GET de la requête HTTP
        if (requete != null) {
            String[] tab = requete.split(" ");
            if (tab.length >= 2) {
                String[] tab2 = tab[1].split("\\?");
                if (tab2.length >= 2) {
                    // Extraction des paramètres GET (tout après '?')
                    params = tab2[1];
                }
            }
        }

       
        
        // Séparer le fichier PHP et les paramètres GET
        String[] cheminSplit = chemin.split("\\?");
        String fichier = cheminSplit[0]; // Le fichier PHP sans les paramètres
        
        
        // Vérifier si le fichier existe
        java.nio.file.Path path = java.nio.file.Paths.get(fichier);
        if (!java.nio.file.Files.exists(path)) {
            sb.append("<html><body><h1>Erreur 404</h1><p>Fichier non trouvé.</p></body></html>");
            return sb.toString();
        }

        
        // Lire le contenu de test2.php et ajouter le code nécessaire sans altérer les balises existantes
        StringBuilder phpScript = new StringBuilder();
         boolean cliParseAlreadyAdded = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(fichier))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("LINE :"+line);
                phpScript.append(line).append("\n");
                if (line.contains("php_sapi_name() === 'cli'")) {
                    cliParseAlreadyAdded = true ;
                }
            }
        }


       if (!cliParseAlreadyAdded) {
         // Si le fichier PHP commence par "<?php", on n'ajoute pas une nouvelle balise PHP
         if (phpScript.indexOf("<?php") == -1) {
            // Ajouter le code PHP pour traiter les paramètres GET si en mode CLI
            phpScript.insert(0, "<?php\nif (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); } ?>\n");
        } else {
            // Si le fichier contient déjà des balises PHP, insérer juste la ligne de traitement
            phpScript.insert(phpScript.indexOf("<?php") + 5, "\nif (php_sapi_name() === 'cli') { parse_str(getenv('QUERY_STRING'), $_GET); }\n");
        }
        
        // Réécrire le fichier test2.php avec le contenu modifié
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier))) {
            writer.write(phpScript.toString());
        }
        
       }

        // Créer le processus pour exécuter le fichier PHP avec le paramètre QUERY_STRING
        ProcessBuilder builder = new ProcessBuilder("php", "-d", "variables_order=EGPCS", fichier);

        // Si des paramètres GET existent, les passer à l'environnement
        if (params != null && !params.isEmpty()) {
            builder.environment().put("QUERY_STRING", params);  // Passer les paramètres GET à PHP via l'environnement
            builder.environment().put("REQUEST_METHOD", "GET");
        }

        // Vérifier que QUERY_STRING est bien passée
        System.out.println("QUERY_STRING (Java) : " + builder.environment().get("QUERY_STRING"));
    
        builder.redirectErrorStream(true); // Rediriger les erreurs vers la sortie standard
        Process process = builder.start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

        // Lire la sortie du processus PHP
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }

        process.waitFor(); // Attendre la fin de l'exécution de PHP

    } catch (Exception e) {
        sb.append("<html><body><h1>Erreur PHP</h1><p>").append(e.getMessage()).append("</p></body></html>");
    }

    return sb.toString();
}


public static String extraireChemin(String requete, String chemin) {
    chemin = "/home/zo/Documents/SOCKET/htdocs/";
    if (requete != null) {
        String[] tab = requete.split(" ");
        
        if (tab.length >= 2) {
            String[] tab2 = tab[1].split("\\?");
            if (tab2.length >= 2) {
                // Extraction des paramètres GET
                String params = tab2[1];
                System.out.println("Paramètres GET : " + params);
                
                // Assurer que le chemin de base se termine par "/"
                if (!chemin.endsWith("/")) {
                    chemin += "/";
                }
                chemin += tab2[0]; // Chemin sans les paramètres
                return chemin; // Retourne chemin complet avec paramètres
            } else {
                if (tab[1].length() == 1) {
                    chemin += "list_files.php";
                } else if (tab[1].equals("/favicon.ico")) {
                    // Pas de modification du chemin pour le favicon
                    chemin = chemin;
                } else {
                    // Assurer que le chemin de base se termine par "/"
                    if (!chemin.endsWith("/")) {
                        chemin += "/";
                    }
                    chemin += tab[1]; // Ajouter le fichier à la fin du chemin
                }
                return chemin;
            }
        }
    }
    return chemin + "hh"; // Retourner un chemin par défaut en cas d'erreur
}




}
