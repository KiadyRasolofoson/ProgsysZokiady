import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ServerControl {
    private static ServerHTTP server; // Référence vers le serveur
    private static Thread serverThread;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Contrôle du Serveur HTTP");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JButton startButton = new JButton("Démarrer le serveur");
        JButton stopButton = new JButton("Arrêter le serveur");
        stopButton.setEnabled(false); // Désactivé au début

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                serverThread = new Thread(() -> {
                    try {
                        ServerHTTP.main(null); // Lancer le serveur
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                });
                serverThread.start();
                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                JOptionPane.showMessageDialog(frame, "Serveur démarré !");
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    serverThread.interrupt(); // Interrompre le thread du serveur
                    startButton.setEnabled(true);
                    stopButton.setEnabled(false);
                    JOptionPane.showMessageDialog(frame, "Serveur arrêté !");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        frame.add(startButton);
        frame.add(stopButton);
        frame.setVisible(true);
    }
}
