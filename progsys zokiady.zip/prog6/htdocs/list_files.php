<?php
$directory = "./htdocs"; // Chemin vers le répertoire htdocs

function listFilesAndDirectories($directory) {
    $files = scandir($directory);

    // Filtrer les fichiers pour ne garder que les html, php et txt
    $allowedExtensions = ['html', 'php', 'txt'];
    $fileList = [];
    $directoryList = [];

    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = $directory . DIRECTORY_SEPARATOR . $file;
        if (is_dir($path)) {
            $directoryList[] = $file;
        } elseif (is_file($path)) {
            $extension = pathinfo($file, PATHINFO_EXTENSION);
            if (in_array($extension, $allowedExtensions)) {
                $fileList[] = $file;
            }
        }
    }

    // Trier les dossiers et fichiers
    sort($directoryList);
    sort($fileList);

    return array_merge($directoryList, $fileList);
}

$items = listFilesAndDirectories($directory);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des fichiers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            transition: background-color 0.3s;
        }

        ul li:hover {
            background-color: #eef;
        }

        ul li a {
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
        }

        ul li a:hover {
            text-decoration: underline;
        }

        .folder {
            color: #FF9800;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Liste des fichiers et dossiers</h1>
        <ul>
            <?php foreach ($items as $item): ?>
                <li class="<?php echo is_dir($directory . DIRECTORY_SEPARATOR . $item) ? 'folder' : 'file'; ?>">
                    <a href="<?php echo $item; ?>" target="_blank">
                        <?php echo $item; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
