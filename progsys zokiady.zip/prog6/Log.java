import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Log {

    public static String LOG_FILE(String type){
        if(type=="ACCESS"){
            return "logs/access.log";
        }
        return "logs/error.log";
    }

    // Fonction pour ajouter un message d'accès au fichier log
    public static void AjouterAccess(String texte) {
        AjouterLog("ACCESS", texte);
    }

    // Fonction pour ajouter un message d'erreur au fichier log
    public static void AjouterError(String texte) {
        AjouterLog("ERROR", texte);
    }

    // Méthode générique pour écrire un log avec un type
    private static void AjouterLog(String type, String texte) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE(type), true))) {
            // Ajouter la date et l'heure au format [AAAA-MM-JJ HH:mm:ss]
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String logEntry = String.format("[%s] [%s] %s%n", timestamp, type, texte);
            writer.write(logEntry);
        } catch (IOException e) {
            System.err.println("Impossible d'écrire dans le fichier log: " + e.getMessage());
        }
    }

    // Exemple d'utilisation
    public static void main(String[] args) {
        AjouterAccess("Connexion réussie pour l'utilisateur X.");
        AjouterError("Erreur lors de l'exécution de la requête SQL.");
    }
}
